<?php 
/**
* Plugin Name: Wordpress CMS Module
* Plugin URI: https://wordpress.org/
* Description: Wordpress CMS module.
* Version: 5.3.0
* Author: Wordpress CMS
* Author URI: https://wordpress.org/
**/
