<h1 class="abt_titl"><?php _e( 'Please visit us at ', 'ultimate-social-media-icons' ); ?> <a href="http://ultimatelysocial.com">Ultimatelysocial.com</a> <?php _e(" or write to us at ",'ultimate-social-media-icons') ?> support@ultimatelysocial.com</h1>

