<template>
	<portal to="footerButtons">
		<div class="wptb-settings-button-container">
			<slot></slot>
		</div>
	</portal>
</template>
