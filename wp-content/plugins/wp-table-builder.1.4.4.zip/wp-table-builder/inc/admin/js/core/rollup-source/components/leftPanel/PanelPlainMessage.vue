<template>
	<div class="wptb-panel-plain-message">
		<slot></slot>
	</div>
</template>
