<template functional>
	<span class="dashicons dashicons-image-rotate wptb-settings-fetching"></span>
</template>
