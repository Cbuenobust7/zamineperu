<template>
	<div class="wptb-controls-flex-row">
		<slot></slot>
	</div>
</template>
