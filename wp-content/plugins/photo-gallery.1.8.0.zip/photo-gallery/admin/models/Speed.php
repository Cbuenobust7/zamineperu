<?php

/**
 * Class SpeedModel_bwg
 */
class SpeedModel_bwg {

}
