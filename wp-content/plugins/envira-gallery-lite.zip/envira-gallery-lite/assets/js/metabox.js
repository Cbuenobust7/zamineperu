/**
* You'll need to use CodeKit or similar, as this file is a placeholder to combine
* the following JS files into min/metabox-min.js:
*/
// @codekit-append "gallery-preview.js";
// @codekit-append "gallery-types.js";
// @codekit-append "gallery-help.js";
// @codekit-append "media-bulk-edit.js";
// @codekit-append "media-delete.js";
// @codekit-append "media-edit.js";
// @codekit-append "media-insert.js";
// @codekit-append "media-manage.js";
// @codekit-append "media-move.js";
// @codekit-append "media-upload.js";

jQuery( document ).ready( function( $ ) {


} );