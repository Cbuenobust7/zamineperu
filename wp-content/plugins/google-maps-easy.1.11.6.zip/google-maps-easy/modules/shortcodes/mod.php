<?php
class shortcodesGmp extends moduleGmp {

}