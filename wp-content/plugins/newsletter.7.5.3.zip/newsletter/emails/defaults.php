<?php

// This file is used only on first installation!

$options = array(
    'theme'=>'default'
);
