<?php

/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage zamine
 * @since Zamine 1.0
 */
$menu = getMenuArray('main');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="profile" href="http://gmpg.org/xfn/11">
  <?php if (is_singular() && pings_open(get_queried_object())) : ?>
    <link rel="pingback" href="<?php echo esc_url(get_bloginfo('pingback_url')); ?>">
  <?php endif; ?>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/libs/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;200;300;400;500;600;700;800;900&family=Open+Sans&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:wght@100;400&family=Rubik&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css">
  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <?php wp_body_open(); ?>
  <header class="header">
    <div class="wrapper">
      <div class="container d-flex justify-content-end align-items-center">
        <div class="menu-item menu-lang">
          <ul class="header__list-languages"><?php pll_the_languages(); ?></ul>
        </div>
        <div class="menu-item">
          <a href="<?php echo home_url(); ?>">
            <span class="material-icons-outlined">
              headset_mic
            </span>
          </a>
        </div>
        <div class="menu-item">
          <a href="#">
            <span class="material-icons">
              search
            </span>
          </a>
        </div>
        <div class="menu-item">
          <a href="#" class="open-menu">
            <span class="material-icons">
              menu
            </span>
          </a>
        </div>
      </div>
    </div>
  </header>
  <div class="header-menu ">
    <div class="wrapper">
      <div class="container">
        <a href="<?php echo home_url(); ?>">
          <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png">
        </a>

        <div class="row py-5">
          <div class="col-md-3 pr-md-0">
            <div class="menu py-0 py-sm-4">
              <ul class="">
                <?php

                foreach ($menu as $key => $value) {
                  $title = $value->title;
                  $url = $value->url;
                  $current = $value->current;
                  echo "<li>
                          <a href='$url'>$title</a>
                        </li>";
                }

                ?>
              </ul>
            </div>
          </div>
          <div class="col-md-12 offset-lg-1 col-lg-8">
            <div class="row">
              <div class="col-md-6">
                <?php
                $menu1 = getMenuArray(22);
                foreach ($menu1 as $key => $value) {
                  $title = $value->title;
                  $ID = $value->ID;
                  $url = $value->url;
                  $icono_menu = get_field('icono_menu', $ID);
                  echo <<<EOT
                    <div class="menu-link">
                      <a href="$url">
                        <img src="$icono_menu" class="img-fluid">
                        <span>$title</span>
                      </a>
                    </div>
                    EOT;
                }

                ?>
              </div>
              <div class="col-md-6">
                <?php
                $menu1 = getMenuArray(23);
                foreach ($menu1 as $key => $value) {
                  $title = $value->title;
                  $ID = $value->ID;
                  $url = $value->url;
                  $icono_menu = get_field('icono_menu', $ID);
                  echo <<<EOT
                    <div class="menu-link">
                      <a href="$url">
                        <img src="$icono_menu" class="img-fluid">
                        <span>$title</span>
                      </a>
                    </div>
                    EOT;
                }

                ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>