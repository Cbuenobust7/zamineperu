<?php

add_theme_support('post-thumbnails');

add_action('wp_enqueue_scripts', 'zamine_styles');
add_action('wp_enqueue_scripts', 'zamine_scripts');

function zamine_styles()
{
	$theme_version = wp_get_theme()->get('Version');
	wp_enqueue_style('zamine-style', get_template_directory_uri() . '/assets/css/main.css', null, $theme_version);
}

function zamine_scripts()
{
	$theme_version = wp_get_theme()->get('Version');
	wp_enqueue_script('zamine-js', get_template_directory_uri() . '/assets/js/main.js', array(), $theme_version, true);
}

function myplugin_settings()
{
	// Add tag metabox to page
	register_taxonomy_for_object_type('post_tag', 'page');
	// Add category metabox to page
	register_taxonomy_for_object_type('category', 'page');
}
// Add to the admin_init hook of your theme functions.php file 
add_action('init', 'myplugin_settings');
add_filter('redirect_canonical', 'zamine_disable_redirect_canonical');

function zamine_disable_redirect_canonical($redirect_url)
{
	if (is_singular()) $redirect_url = false;
	return $redirect_url;
}

function zamine_pagination()
{
	global $wp_query;

	$big = 999999;

	$pages = paginate_links([
		'format' => '?paged=%#%',
		'current' => max(1, get_query_var('paged')),
		'total' => $wp_query->max_num_pages,
		'type'  => 'array',
	]);

	if (is_array($pages)) {
		$paged = (get_query_var('paged') == 0) ? 1 : get_query_var('paged');
		echo '<ul class="pagination justify-content-center">';
		foreach ($pages as $k => $page) {
			$current = (strpos($page, 'current') !== FALSE) ? 'disabled' : '';
			$page = str_replace('page-numbers', 'page-link', $page);
			echo "<li class=\"page-item $current\">$page</li>";
		}
		echo '</ul>';
	}
}

function getServicios()
{
	$tipos = get_field("tipos");
	$array = [];

	foreach ($tipos as $key => $idCategory) {
		$nombre = get_the_category_by_ID($idCategory);
		$servicios =  query_posts([
			'post_type' => 'servicios',
			'posts_per_page' => 10000,
			'tax_query' => array(
				array(
					'taxonomy' => 'tipos_servicios',
					'field' => 'id',
					'terms' => $idCategory,
				)
			),
		]);
		$data = [
			"nombre" => $nombre,
			'servicios' => $servicios,
			"idCategory" => $idCategory,
		];
		$array[] = $data;
	}
	return $array;
}
include 'core/helpers.php';
