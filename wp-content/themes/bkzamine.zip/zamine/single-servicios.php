<?php get_header();
$servicio = get_field("servicio");
//echo json_encode(get_fields());
?>
<div class="page-product">
  <div class="info py-5">
    <div class="wrapper px-5">
      <a href="/">
        <img src="<?php echo get_template_directory_uri(); ?>/images/small-logo.png" class="img-fluid mb-4">
      </a>
    </div>
  </div>

  <?php
  $category = reset(wp_get_post_terms(get_the_ID(), 'tipos_servicios'));
  ?>

  <?php if ($category) : ?>
    <div class="wrapper">
      <div class="bar bar--gray my-4 mx-auto"></div>
      <h2 class="subtitle-gray text-center pb-5"><?php echo $category->name ?></h2>
    </div>
  <?php endif; ?>

  <div class="product-info py-5">
    <div class="wrapper">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <div class="mb-5">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Inicio</a></li>
                <?php if ($servicio) : ?>
                  <li class="breadcrumb-item"><a href="<?php echo get_the_permalink($servicio->ID); ?>"><?php echo $servicio->post_title ?></a></li>
                <?php endif; ?>
                <?php the_title('<li class="breadcrumb-item active" aria-current="page">', '</li>'); ?>
              </ol>
            </div>
            <div class="row">
              <div class="col-md-6 mb-4">
                <img src="<?php echo get_the_post_thumbnail_url() ?>" class="img-fluid">
              </div>
              <div class="col-md-6">
                <div class="product--info--details pl-md-4">
                  <div class="mb-4">
                    <?php the_title('<h2>', '</h2>'); ?>
                  </div>

                  <div id="accordionSingleService" class="accordion-product">
                    <div class="accordion--item mb-4">
                      <h5 class="mb-0">
                        <a href="#" data-toggle="collapse" data-target="#description">
                          <span class="material-icons">
                            add
                          </span>
                          <span>Descripción</span>
                        </a>
                      </h5>
                      <div id="description" class="pt-3 pl-md-4 collapse show" data-parent="#accordionSingleService">
                        <?php the_content(); ?>
                      </div>
                    </div>
                    <div class="accordion--item mb-4">
                      <h5 class="mb-0">
                        <a href="#" data-toggle="collapse" data-target="#ficha" class="collapsed">
                          <span class="material-icons">
                            add
                          </span>
                          <span>Ficha técnica</span>
                        </a>
                      </h5>
                      <div id="ficha" class="pt-3 pl-md-4  collapse" data-parent="#accordionSingleService">
                        <a href="<?php echo get_field('ficha_tecnica'); ?>" class="btn btn-link btn-download" download="Ficha técnica">
                          <span class="material-icons">
                            library_books
                          </span>
                          Descargar Ficha Técnica
                        </a>
                      </div>
                    </div>
                  </div>
                  <a class="btn btn-orange" href="<?php echo home_url('contactanos') ?>">
                    SOLICITA TU COTIZACIÓN
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>